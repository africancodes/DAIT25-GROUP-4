# MobilePhoneRecords
The following project was created in visual studio 2015
where it will contain the following items that make 
it a complete project:
<li>database</li>
<li>backend</li>
<li>frontend</li>
